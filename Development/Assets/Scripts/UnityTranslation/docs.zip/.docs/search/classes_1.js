var searchData=
[
  ['languagecode',['LanguageCode',['../class_unity_translation_1_1_language_code.html',1,'UnityTranslation']]],
  ['languagename',['LanguageName',['../class_unity_translation_1_1_language_name.html',1,'UnityTranslation']]],
  ['languagesystemname',['LanguageSystemName',['../class_unity_translation_1_1_language_system_name.html',1,'UnityTranslation']]]
];
