var searchData=
[
  ['pluralsfunction',['PluralsFunction',['../class_unity_translation_internal_1_1_plurals_rules.html#aea74c525164e20fff1522881cc43ccb0',1,'UnityTranslationInternal::PluralsRules']]],
  ['processtokenvalue',['processTokenValue',['../class_unity_translation_internal_1_1_utils.html#abbf0fe9977ccffecd5b8955207e8b786',1,'UnityTranslationInternal::Utils']]]
];
