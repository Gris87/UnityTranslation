var searchData=
[
  ['addlanguagechangedlistener',['addLanguageChangedListener',['../class_unity_translation_1_1_translator.html#a5793a41e8959350df90ae1f2f4b1bbec',1,'UnityTranslation.Translator.addLanguageChangedListener()'],['../class_unity_translation_internal_1_1_translator.html#a1e2790f19856c8e46b4778f7a91292f2',1,'UnityTranslationInternal.Translator.addLanguageChangedListener()']]]
];
