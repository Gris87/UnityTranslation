var searchData=
[
  ['unitytranslation',['UnityTranslation',['../namespace_unity_translation.html',1,'']]],
  ['unitytranslationinternal',['UnityTranslationInternal',['../namespace_unity_translation_internal.html',1,'']]]
];
