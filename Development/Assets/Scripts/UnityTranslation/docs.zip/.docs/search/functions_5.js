var searchData=
[
  ['nametolanguage',['nameToLanguage',['../class_unity_translation_1_1_language_name.html#a2570a90204d886e078ff9821594184cf',1,'UnityTranslation::LanguageName']]]
];
