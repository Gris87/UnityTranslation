var searchData=
[
  ['defaultlanguage',['defaultLanguage',['../class_unity_translation_internal_1_1_translator_1_1_section_tokens.html#af84ccd3896bd52c4090eb59ba58d8be1',1,'UnityTranslationInternal::Translator::SectionTokens']]]
];
