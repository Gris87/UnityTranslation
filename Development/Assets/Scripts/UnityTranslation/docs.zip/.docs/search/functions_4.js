var searchData=
[
  ['languagetocode',['languageToCode',['../class_unity_translation_1_1_language_code.html#a5f247021e185d25acace5b9b4c82d804',1,'UnityTranslation::LanguageCode']]],
  ['languagetoname',['languageToName',['../class_unity_translation_1_1_language_name.html#a051e5692d28e555faf8afdc1dfad0ec1',1,'UnityTranslation::LanguageName']]],
  ['languagetosystemlanguage',['languageToSystemLanguage',['../class_unity_translation_1_1_language_system_name.html#af83a1e247f69a410851daaa0ac82b6ab',1,'UnityTranslation::LanguageSystemName']]],
  ['loadsection',['LoadSection',['../class_unity_translation_1_1_translator.html#a4294ff11c4f94c3e87a30ff842053a6e',1,'UnityTranslation.Translator.LoadSection()'],['../class_unity_translation_internal_1_1_translator.html#a765a0af04a39ded9ac6caf8fea191104',1,'UnityTranslationInternal.Translator.LoadSection()']]]
];
