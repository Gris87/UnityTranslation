var searchData=
[
  ['sectionid',['SectionID',['../class_unity_translation_1_1_r_1_1sections.html#a53d9c409e8e6504d4c4b27b16ae10347',1,'UnityTranslation::R::sections']]],
  ['strings',['strings',['../class_unity_translation_1_1_r.html#a29c20c17cdcb27878b6fcea43d7867be',1,'UnityTranslation::R']]]
];
