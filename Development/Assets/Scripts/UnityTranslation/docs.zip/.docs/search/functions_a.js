var searchData=
[
  ['unloadsection',['UnloadSection',['../class_unity_translation_1_1_translator.html#a6950d8745c9564269162ccdfd0d7f8eb',1,'UnityTranslation.Translator.UnloadSection()'],['../class_unity_translation_internal_1_1_translator.html#adf150efbf6747ffef8a0a65430257738',1,'UnityTranslationInternal.Translator.UnloadSection()']]]
];
