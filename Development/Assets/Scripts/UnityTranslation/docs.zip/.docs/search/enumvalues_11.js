var searchData=
[
  ['rajasthani',['Rajasthani',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273ad6e2f38d52b96b3869c4f8c158faf1f8',1,'UnityTranslation']]],
  ['rapanui',['Rapanui',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273ac5907c2d005f0349854c5bbd4f73fb85',1,'UnityTranslation']]],
  ['rarotongan',['Rarotongan',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a04e0f36815eadd0dab92bfaadd1536d1',1,'UnityTranslation']]],
  ['riffian',['Riffian',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a5eba1835566ba78a1a89eefa72d88e45',1,'UnityTranslation']]],
  ['romagnol',['Romagnol',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a8d282d6b38bfe4e45ea73e56e52afe74',1,'UnityTranslation']]],
  ['romanian',['Romanian',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273aefa7394ecaa7fc7076a9da13a77236b8',1,'UnityTranslation']]],
  ['romansh',['Romansh',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a88c2cd3ecbb09b23c456ba8b33dfd266',1,'UnityTranslation']]],
  ['romany',['Romany',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a2928692d117669cc7bdc4f8922399bee',1,'UnityTranslation']]],
  ['rombo',['Rombo',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a77f6f2756591d202ab812513d7083eb5',1,'UnityTranslation']]],
  ['rotuman',['Rotuman',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a56694a1274261fb237fded8963d5121e',1,'UnityTranslation']]],
  ['roviana',['Roviana',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a918327085809551e6161736ff0b6cca6',1,'UnityTranslation']]],
  ['rundi',['Rundi',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a899f2e4cfae66e109ed82951bef7db4d',1,'UnityTranslation']]],
  ['russian',['Russian',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273adeba6920e70615401385fe1fb5a379ec',1,'UnityTranslation']]],
  ['rusyn',['Rusyn',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a1a5fd4668e52b2496286718f7a023302',1,'UnityTranslation']]],
  ['rwa',['Rwa',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273acc65b31204f0f0963ebe620663b0a5b5',1,'UnityTranslation']]]
];
