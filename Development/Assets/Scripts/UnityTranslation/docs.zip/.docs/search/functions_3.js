var searchData=
[
  ['issectionloaded',['IsSectionLoaded',['../class_unity_translation_1_1_translator.html#a03f5559850df00020c94d7ac3fc53295',1,'UnityTranslation.Translator.IsSectionLoaded()'],['../class_unity_translation_internal_1_1_translator.html#a67d3f296fdd58377df23a20bfaf2b865',1,'UnityTranslationInternal.Translator.IsSectionLoaded()']]]
];
