var searchData=
[
  ['removelanguagechangedlistener',['removeLanguageChangedListener',['../class_unity_translation_1_1_translator.html#ac713d0341abcb966d57512277376e545',1,'UnityTranslation.Translator.removeLanguageChangedListener()'],['../class_unity_translation_internal_1_1_translator.html#a58095543e5f186857cbd1923eef20914',1,'UnityTranslationInternal.Translator.removeLanguageChangedListener()']]]
];
