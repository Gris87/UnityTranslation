var searchData=
[
  ['sectionlocaletokens',['SectionLocaleTokens',['../class_unity_translation_internal_1_1_translator_1_1_section_locale_tokens.html#a5b5a3289bef7c370a8f8203b16fc7583',1,'UnityTranslationInternal::Translator::SectionLocaleTokens']]],
  ['sectiontokens',['SectionTokens',['../class_unity_translation_internal_1_1_translator_1_1_section_tokens.html#aadf202b1e4e158bfadfe127a16b2b014',1,'UnityTranslationInternal::Translator::SectionTokens']]],
  ['systemlanguagetolanguage',['systemLanguageToLanguage',['../class_unity_translation_1_1_language_system_name.html#a9f7d8f1876a2efebe8029723cac5e1ab',1,'UnityTranslation::LanguageSystemName']]]
];
