var searchData=
[
  ['getquantitystring',['getQuantityString',['../class_unity_translation_1_1_translator.html#a50f058cca7c6e753aa0196279274cabf',1,'UnityTranslation.Translator.getQuantityString(R.plurals id, double quantity)'],['../class_unity_translation_1_1_translator.html#a6fd91c5a04ce5d92e00cead769ce5838',1,'UnityTranslation.Translator.getQuantityString(R.plurals id, double quantity, params object[] formatArgs)']]],
  ['getstring',['getString',['../class_unity_translation_1_1_translator.html#ac6140252e7154c8a30d17d07a2e96e0e',1,'UnityTranslation.Translator.getString(R.strings id)'],['../class_unity_translation_1_1_translator.html#a591a72a77e193d718f5b29198b6cb229',1,'UnityTranslation.Translator.getString(R.strings id, params object[] formatArgs)']]],
  ['getstringarray',['getStringArray',['../class_unity_translation_1_1_translator.html#a78d1819004464cdd113cb088ea4d6f06',1,'UnityTranslation::Translator']]]
];
